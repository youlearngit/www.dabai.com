<?php
return array(
	//'配置项'=>'配置值'
    //制作布局
    'layout_on' =>FALSE,//是否开启布局
    'layout_name' =>'layout',//当前布局名称，默认为layout,布局文件本质也是模板文件，需要创建带.html后缀的物理文件
    'autoSub'       =>  FALSE, 
);