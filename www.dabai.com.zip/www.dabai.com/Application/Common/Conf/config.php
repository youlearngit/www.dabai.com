<?php
return array(
	//'配置项'=>'配置值'
  'DB_TYPE' => 'mysql',
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'dabai',
  'DB_USER' => 'root',
  'DB_PWD' => '123456',
  'DB_PORT' => 3306,
  'DB_PREFIX' => 'gw_',
  'DB_CHARSET' => 'utf8',
);