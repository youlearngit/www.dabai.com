
CREATE TABLE IF NOT EXISTS `gw_article` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `num` varchar(3) NOT NULL COMMENT '招聘人数',
  `author` varchar(20) NOT NULL,
  `pic` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `keywords` varchar(60) NOT NULL,
  `des` varchar(255) NOT NULL,
  `rem` tinyint(1) NOT NULL DEFAULT '0',
  `cateid` mediumint(5) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

create table if not exists gw_cate(
id mediumint not null auto_increment,
name varchar(30) not null,
type tinyint default '1',
class tinyint(1) not null default '1' comment '栏目级别',
sort mediumint default '50',
pic varchar(255) default null,
content text not null,
keywords varchar(60) default null,
des varchar(255) default null,
parentid mediumint not null,
primary key(id)
)engine=myisam default charset=utf8;