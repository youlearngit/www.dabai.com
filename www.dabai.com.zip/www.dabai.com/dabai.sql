-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 2018-08-21 01:54:18
-- 服务器版本： 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dabai`
--

-- --------------------------------------------------------

--
-- 表的结构 `gw_article`
--

DROP TABLE IF EXISTS `gw_article`;
CREATE TABLE IF NOT EXISTS `gw_article` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `num` varchar(3) NOT NULL COMMENT '招聘人数',
  `author` varchar(20) NOT NULL,
  `pic` varchar(60) NOT NULL,
  `content` text NOT NULL,
  `keywords` varchar(60) NOT NULL,
  `des` varchar(255) NOT NULL,
  `rem` tinyint(1) NOT NULL DEFAULT '0',
  `cateid` mediumint(5) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `gw_article`
--

INSERT INTO `gw_article` (`id`, `title`, `num`, `author`, `pic`, `content`, `keywords`, `des`, `rem`, `cateid`, `time`) VALUES
(2, '大白网络简介', '', '', './Public/Uploads/2018-08-20/5b7a5c6cd7e3c.jpg', '&lt;p&gt;&amp;nbsp;公司概况：芜湖大白网络技术公司，成立于2015年，注册资金50万，员工40余名，拥有专业的新媒体运营团队，技术团队，是一家新媒体运营公司&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;发展状况：主要面向芜湖大中小商家，为上百商家提供了网站策划服务.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;公司文化：公司以“赢在，志在恒心”为核心价值，一切以用户需求为中心，希望通过专业水平和不懈努力，重塑企业网络形象，为企业产品推广文化发展提供服务指导.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;公司主要产品：主要为企业提供网站策划，网站设计制作，网站推广优化等服务.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;销售业绩以及网络：为中小企业提供网站策划服务，现阶段主要面向芜湖地区&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;售后服务：芜湖大白网络有详细的售后服务体系，提供终生策划指导服务.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 芜湖大白网络技术有限公司，创立于2015年7月27日，是一家致力于为芜湖各企业及商家提供微信营销产品、平台和解决方案、策划大型线上及线下活动的创新型自媒体公司。&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;公司团队已先后成功运营“芜湖派”、“吃遍芜湖”、“芜湖亲子”等芜湖本地知名微信公众号，获得本地20多万粉丝的持续关注及支持，&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;并多次独家策划并成功举办了在芜湖传播率、参与度极高的大型活动。为打造芜湖都市生活方式第一指南而努力！&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt; 时光荏苒，大白网络已经三岁啦~&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp;在这三年的时间里，大白网络和大家一起成长，一起进步&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 感谢这一路走来有大家的陪伴&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space:pre&quot;&gt;&lt;/span&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;在接下来的日子里，希望大家能够继续陪伴&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;white-space: pre;&quot;&gt;&lt;/span&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; 一起努力，和大白网络携手走向更好的明天！&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '', '', 0, 5, 0),
(3, '新媒体运营', '', '', '', '&lt;p&gt;新媒体运营部所运营的订阅号“芜湖派”、“吃遍芜湖”服务号“芜湖优选生活”、“芜湖购”、“芜湖今日头牌”等，已获得20多万粉丝持续关注及支持，并且多次独家策划举办大型活动，在芜湖本地形成了极大地传播率。&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '', '', 0, 6, 0);

-- --------------------------------------------------------

--
-- 表的结构 `gw_cate`
--

DROP TABLE IF EXISTS `gw_cate`;
CREATE TABLE IF NOT EXISTS `gw_cate` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `type` tinyint(4) DEFAULT '1',
  `class` tinyint(1) NOT NULL DEFAULT '1' COMMENT '栏目级别',
  `sort` mediumint(9) DEFAULT '50',
  `pic` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `keywords` varchar(60) DEFAULT NULL,
  `des` varchar(255) DEFAULT NULL,
  `parentid` mediumint(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `gw_cate`
--

INSERT INTO `gw_cate` (`id`, `name`, `type`, `class`, `sort`, `pic`, `content`, `keywords`, `des`, `parentid`) VALUES
(1, '公司简介', 1, 1, 50, NULL, '', NULL, NULL, 0),
(2, '企业文化', 1, 1, 50, NULL, '', NULL, NULL, 0),
(3, '案例展示', 1, 1, 50, NULL, '', NULL, NULL, 0),
(4, '人员招聘', 1, 1, 50, NULL, '', NULL, NULL, 0),
(5, '大白网络简介', 1, 2, 50, NULL, '', NULL, NULL, 1),
(6, '大白网络部门', 1, 2, 50, NULL, '', NULL, NULL, 1),
(7, '办公环境', 1, 2, 50, NULL, '', NULL, NULL, 1),
(8, '大白文化', 1, 2, 50, NULL, '', NULL, NULL, 2),
(9, '优秀案例', 1, 2, 50, NULL, '', NULL, NULL, 3),
(10, '人员风采', 1, 2, 50, NULL, '', NULL, NULL, 2),
(11, '联系我们', 1, 2, 50, NULL, '', NULL, NULL, 4);

-- --------------------------------------------------------

--
-- 表的结构 `gw_user`
--

DROP TABLE IF EXISTS `gw_user`;
CREATE TABLE IF NOT EXISTS `gw_user` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `username` varchar(32) NOT NULL COMMENT '姓名',
  `pwd` varchar(32) NOT NULL COMMENT '密码',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `gw_user`
--

INSERT INTO `gw_user` (`id`, `username`, `pwd`, `status`) VALUES
(5, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 1),
(6, '郑平', 'e10adc3949ba59abbe56e057f20f883e', 1),
(7, '黄伟', 'e10adc3949ba59abbe56e057f20f883e', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
